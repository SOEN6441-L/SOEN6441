package gameviews;

import java.util.Observable;

import gamemodels.NodeRecord;

public class ObservableNodes extends Observable{
	private NodeRecord[][] localNodes;
	public void initDimensionX(int x){
		if (x>0)
			localNodes = new NodeRecord[x][];
	}
	public void initDimensionY(int indexX, int y){
		if (y>0)
			localNodes[indexX] = new NodeRecord[y];
	}
	public void initValue(int x, int y, String name, int number){
		localNodes[x][y] = new NodeRecord(name,number);
	}
	public void increaseValue(int x, int y){
		localNodes[x][y].setNumber(localNodes[x][y].getNumber()+1);
		setChanged();
		notifyObservers("Step 4 - Player"+(x+1)+" place one army on "+localNodes[x][y].getName());
	}
	public NodeRecord[][] getNodes(){
		return localNodes;
	}
}
